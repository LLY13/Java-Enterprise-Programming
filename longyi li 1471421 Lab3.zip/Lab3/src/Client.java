import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Client extends JFrame implements ActionListener, Runnable{
	
	private static final long serialVersionUID = 980389841528802556L;
	
	
	// define the user interface components
	JTextField chatInput = new JTextField(50);
	JTextArea chatHistory = new JTextArea(5,50);
	JButton chatMessage = new JButton("Send");
	JPanel panel = new JPanel();
	JScrollPane clientPane = new JScrollPane();
	String[] threadNames = {" "," "," "," "," "," "," "," "," "," "};
	JList clientList = new JList(threadNames);
	int threadNum = 0;
	String privateUser;
	
	// define the socket and io streams
	Socket client;
	DataInputStream dis;
	DataOutputStream dos;
	
	public Client()
	{
		// create the user interface and setup an action listener linked to the send message button
		
		Container contentPane = this.getContentPane();
		contentPane.setLayout(new BorderLayout());
		
		//develop prompt to allow a user (client) to enter the nickname / handle for their client suggest using JOptionPane
		String nickName = JOptionPane.showInputDialog("Please input your Nickname");
		
		//add in extra user interface components to allow a user to select the remote client that they want to send a message to suggest using a JList

		clientPane.setPreferredSize(new Dimension(80, 90));
		clientPane.setViewportView(clientList);
		
		clientList.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent evt) {
		        JList list = (JList)evt.getSource();
		        if (evt.getClickCount() == 2) {

		            // Double-click detected
		            int index = list.locationToIndex(evt.getPoint());
		            privateUser = threadNames[index];
		            chatInput.setText("/" + privateUser + ":  ");
		        }
		    }
		});
		
		panel.add(new JScrollPane(chatHistory));
		panel.add(clientPane);
		contentPane.add(chatInput, BorderLayout.CENTER);
		contentPane.add(chatMessage,BorderLayout.EAST);
		contentPane.add(panel, BorderLayout.NORTH);
		
		setTitle(nickName);
		
		pack();
		setVisible(true);
		
		chatMessage.addActionListener(this);
		
		// attempt to connect to the defined remote host
		try {
			client = new Socket("localhost",5000);
			dis = new DataInputStream(client.getInputStream());
			dos = new DataOutputStream(client.getOutputStream());
			
			dos.writeInt(ServerConstants.REGISTER_CLIENT);
			dos.writeUTF(nickName);
			dos.flush();
			
			// define a thread to take care of messages sent from the server
			Thread clientThread = new Thread(this);
			clientThread.start();
		}
		catch (UnknownHostException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	

	/**
	 * Method to respond to button press events, and send a chat message to the Server
	 */
	
	@Override
	public void actionPerformed(ActionEvent event)
	{
		try {
			if(chatInput.getText().charAt(0) != '/'){
				dos.writeInt(ServerConstants.CHAT_MESSAGE); // determine the type of message to be sent
				dos.writeUTF(chatInput.getText()); // message payload
				chatInput.setText("");
				dos.flush(); // force the message to be sent (sometimes data can be buffered)
			}else{
				dos.writeInt(ServerConstants.PRIVATE_MESSAGE);
				dos.writeUTF(chatInput.getText());
				chatInput.setText("/" + privateUser + ":  ");
				dos.flush(); // force the message to be sent (sometimes data can be buffered)
			}
		}
		catch (IOException e){
			e.printStackTrace();
		}
	}

	// process messages from the server
	@Override
	public void run()
	{
		while(true)
		{
			try {
				int messageType = dis.readInt(); // receive a message from the server, determine message type based on an integer
				
				// decode message and process
				switch(messageType)
				{
					case ServerConstants.CHAT_BROADCAST:
						chatHistory.append(dis.readUTF()+"\n");
						break;
					case ServerConstants.REGISTER_CLIENT:
						String threadName = dis.readUTF();
						threadNames[threadNum++] = threadName;
						clientPane.setViewportView(clientList);
						break;
					case ServerConstants.PRIVATE_MESSAGE:
						chatHistory.append(dis.readUTF()+"\n");
						break;
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		
	}
	public static void main(String[] args)
	{
		Client client = new Client();
		client.setVisible(true);
	}
}
