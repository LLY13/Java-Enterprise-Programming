import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;


public class ServerThread extends Thread {

	DataInputStream dis;
	DataOutputStream dos;
	
	Socket remoteClient;
	Server server;
	
	String nickname;
	
	ArrayList<ServerThread> connectedClients; // keep track of all the other clients connected to the Server
	
	public ServerThread(Socket remoteClient, Server server, ArrayList<ServerThread> connectedClients)
	{
		this.remoteClient = remoteClient;
		this.connectedClients = connectedClients;
		try {
			this.dis = new DataInputStream(remoteClient.getInputStream());
			this.dos = new DataOutputStream(remoteClient.getOutputStream());
			this.server = server;
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}

	public void run()
	{
		while(true) // main protocol decode loop
		{
			try {
				int mesgType = dis.readInt(); // read the type of message from the client (must be an integer)
				System.err.println(mesgType);
				
				// decode the message type based on the integer sent from the client
				switch(mesgType)
				{
					case ServerConstants.CHAT_MESSAGE:
						String data = dis.readUTF();
						System.err.println(data);
						//server.getSystemLog().append(remoteClient.getInetAddress()+":"+remoteClient.getPort()+">"+data+"\n");
						for(ServerThread client: connectedClients)
						{
							if(client.equals(this)) // don't send the message to the client that sent the message in the first place
							{
								server.getSystemLog().append(this.nickname + ": "+ data + "\n");
							}
						}
						for(ServerThread otherClient: connectedClients)
						{
							if(!otherClient.equals(this)) // don't send the message to the client that sent the message in the first place
							{
								otherClient.getDos().writeInt(ServerConstants.CHAT_BROADCAST);
								otherClient.getDos().writeUTF(this.nickname + ": "+ data);
							}
						}
						
						break;
					case ServerConstants.REGISTER_CLIENT:
						//develop code to handle new client registrations
						nickname = dis.readUTF();
						server.threadNames[server.threadNum++] = nickname;
						server.clientPane.setViewportView(server.clientList);
						server.getSystemLog().append("Welcome " + nickname+ "\n");
						//broadcast this registration to all other clients connected to the server (similar to the CHAT_BROADCAST message sent to each client above)
						for(ServerThread otherClient: connectedClients)
						{
							if(!otherClient.equals(this)) // don't send the message to the client that sent the message in the first place
							{
								otherClient.getDos().writeInt(ServerConstants.CHAT_BROADCAST);
								otherClient.getDos().writeUTF("Welcome " + nickname+"\n");
								otherClient.getDos().writeInt(ServerConstants.REGISTER_CLIENT);
								otherClient.getDos().writeUTF(nickname);
							}
						}
						for(int i=0;i<server.threadNum-1;i++){
							dos.writeInt(ServerConstants.REGISTER_CLIENT);
							dos.writeUTF(server.threadNames[i]);
						}
						break;	
					case ServerConstants.PRIVATE_MESSAGE:
						// TODO develop code to handle private messages sent by the client
						String privateData = dis.readUTF();
						String[] privateDatas = privateData.split(":");
						for(ServerThread client: connectedClients)
						{
							if(privateDatas[0].equals("/" + client.nickname)) // don't send the message to the client that sent the message in the first place
							{
								client.getDos().writeInt(ServerConstants.PRIVATE_MESSAGE);
								client.getDos().writeUTF(client.nickname + ": "+privateDatas[1]);
								break;
							}
						}
						break;
				}				
			}
			catch (IOException e)
			{
				e.printStackTrace();
				return;
			}
		}
	}

	public DataOutputStream getDos() {
		return dos;
	}
}
