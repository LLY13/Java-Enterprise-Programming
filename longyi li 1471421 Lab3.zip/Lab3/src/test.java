import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame frame = new JFrame();
		frame.setSize(500, 500);
		JScrollPane scrollPane = new JScrollPane();
		String[] names = new String[20];
		JList list = new JList<>(names);
		scrollPane.setViewportView(list);
		scrollPane.setPreferredSize(new Dimension(300, 300));
		frame.add(scrollPane);
		frame.setVisible(true);
	}

}
